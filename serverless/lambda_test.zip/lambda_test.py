import sys

def main(event, context):
    return(event)

if __name__ == '__main__':
    main(event, context)
